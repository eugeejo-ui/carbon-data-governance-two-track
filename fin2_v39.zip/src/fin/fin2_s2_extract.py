"""금융2-3 ② 현재 빈칸 — 보고서 PDF에서 금융배출량·데이터 품질·커버리지가 나오는 쪽만 뽑기

- 입력
  - data/manual/fin_esg_reports.csv : 공시할 만한 보고 단위 목록 (account = 명단 이름, 보고서 위치, pdf_url)
  - data/raw/esg/*.pdf               : 직접 받은 보고서. 파일 이름은 "명단이름__아무거나.pdf"
                                       (예: (주)KB금융지주__2025_데이터북.pdf) — "__" 앞이 명단 이름
  - pdf_url 칸에 주소가 있으면 코드가 직접 받아 같은 폴더에 저장
- 하는 일: 쪽마다 글자를 꺼내 "금융배출량"이 있고 "데이터 품질·품질 점수" 또는 "커버리지·측정 대상·산정 대상"이 함께
           나오는 쪽만 골라, 그 주변 글과 후보 숫자(품질 1.0~5.0점, 커버리지 %)를 쪽 번호와 함께 출력
- 값을 정하지는 않음 — 출력을 보고 사람이 값과 출처(보고서·쪽)를 data/manual/fin_evidence.csv 에 적음
- 필요 패키지: pymupdf (없으면 pypdf). 설치: pip install pymupdf
- 출력: data/processed/fin_s2_snippets.csv · data/processed/esg_snippets/<명단이름>.txt
"""
from pathlib import Path
import re
import sys
import urllib.request

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from fin.fin1_list import key  # noqa: E402

RAW = ROOT / "data" / "raw" / "esg"
LIST = ROOT / "data" / "manual" / "fin_esg_reports.csv"
OUT = ROOT / "data" / "processed" / "fin_s2_snippets.csv"
SNIP = ROOT / "data" / "processed" / "esg_snippets"
FE = re.compile(r"금융배출량|FinancedEmission|Scope3|스코프3|Category15|카테고리15", re.I)
DQ = re.compile(r"데이터품질|품질점수|데이터수준|DataQuality|DQS|PCAF점수|PCAFScore", re.I)
COV = re.compile(r"커버리지|Coverage|측정대상|산정대상|측정비율|산정비율|측정범위|산정범위|포괄률|포괄비율|측정한자산", re.I)
NUM_DQ = re.compile(r"(?<![\d.])([1-5]\.\d{1,2})(?![\d.%])")
NUM_PCT = re.compile(r"(?<![\d.])(\d{1,3}(?:\.\d{1,2})?)\s*%")


def page_texts(path):
    try:
        import fitz  # pymupdf
        with fitz.open(path) as doc:
            return [p.get_text() for p in doc]
    except ImportError:
        pass
    try:
        from pypdf import PdfReader
    except ImportError:
        sys.exit("PDF를 읽을 패키지가 없음 — pip install pymupdf 후 다시 실행")
    return [(p.extract_text() or "") for p in PdfReader(str(path)).pages]


def windows(text, pat, width=220):
    """원문에서 공백을 무시하고 pat이 맞는 곳의 앞뒤 글"""
    flat = re.sub(r"\s+", " ", text)
    comp, idx = [], []
    for i, ch in enumerate(flat):
        if ch != " ":
            comp.append(ch)
            idx.append(i)
    comp = "".join(comp)
    out = []
    for m in pat.finditer(comp):
        a = idx[m.start()]
        out.append(flat[max(0, a - width): a + width])
    return out


def download(url, account):
    RAW.mkdir(parents=True, exist_ok=True)
    name = re.sub(r"[^0-9A-Za-z가-힣._()]", "_", url.split("/")[-1].split("?")[0])[-60:] or "report.pdf"
    path = RAW / f"{account}__{name if name.lower().endswith('.pdf') else name + '.pdf'}"
    if path.exists():
        return path, "받아 둔 파일"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=120) as r:
        body = r.read()
    if not body[:5].startswith(b"%PDF"):
        return None, "PDF가 아님(페이지 주소일 수 있음 — 직접 받아 폴더에 넣을 것)"
    path.write_bytes(body)
    return path, "받음"


def main():
    L = pd.read_csv(LIST, dtype=str).fillna("") if LIST.exists() else pd.DataFrame(columns=["account", "pdf_url"])
    RAW.mkdir(parents=True, exist_ok=True)
    SNIP.mkdir(parents=True, exist_ok=True)
    for r in L.to_dict("records"):                       # 주소가 있으면 받기
        if r.get("pdf_url", "").startswith("http"):
            try:
                _, st = download(r["pdf_url"], r["account"])
            except Exception as ex:  # noqa: BLE001
                st = f"받기 실패 {type(ex).__name__}"
            print(f"  [받기] {r['account']} — {st}", flush=True)
    files = sorted(RAW.glob("*.pdf"))
    want = {key(a): a for a in L.get("account", [])}
    print(f"\n보고서 {len(files)}개 · 대상 목록 {len(want)}곳", flush=True)
    rows, summary = [], []
    for f in files:
        acc = f.name.split("__")[0]
        try:
            pages = page_texts(f)
        except Exception as ex:  # noqa: BLE001
            summary.append(dict(account=acc, file=f.name, pages=0, hit_pages="", dq_candidates="", cov_candidates="",
                                note=f"읽기 실패 {type(ex).__name__}"))
            continue
        hits, dqs, covs, lines = [], [], [], [f"# {acc} — {f.name} ({len(pages)}쪽)"]
        for no, t in enumerate(pages, 1):
            c = re.sub(r"\s+", "", t)
            if not FE.search(c) or not (DQ.search(c) or COV.search(c)):
                continue
            hits.append(no)
            for kind, pat, num in (("품질", DQ, NUM_DQ), ("커버리지", COV, NUM_PCT)):
                for w in windows(t, pat)[:4]:
                    nums = num.findall(w)
                    (dqs if kind == "품질" else covs).extend(f"{x}(p{no})" for x in nums[:4])
                    rows.append(dict(account=acc, file=f.name, page=no, kind=kind, numbers=" ".join(nums[:6]), snippet=w))
                    lines += [f"\n[p{no} · {kind}] 숫자 후보: {' '.join(nums[:6]) or '-'}", w]
        (SNIP / f"{re.sub(r'[^0-9A-Za-z가-힣]', '_', acc)[:40]}.txt").write_text("\n".join(lines), encoding="utf-8")
        summary.append(dict(account=acc, file=f.name, pages=len(pages), hit_pages=" ".join(map(str, hits[:15])),
                            dq_candidates=" ".join(dict.fromkeys(dqs))[:120], cov_candidates=" ".join(dict.fromkeys(covs))[:160],
                            note="" if hits else "금융배출량+품질/커버리지가 함께 나오는 쪽 없음", in_list=key(acc) in want))
    pd.DataFrame(rows).to_csv(OUT, index=False, encoding="utf-8-sig")
    S = pd.DataFrame(summary)
    pd.set_option("display.width", 250)
    pd.set_option("display.max_colwidth", 90)
    pd.set_option("display.max_rows", 200)
    print(f"\n→ {OUT.relative_to(ROOT)} · 쪽별 발췌 {SNIP.relative_to(ROOT)}/")
    print("\n[1] 보고서별 요약 — 후보 숫자(쪽)")
    print(S[["account", "pages", "hit_pages", "dq_candidates", "cov_candidates", "note"]].to_string(index=False) if len(S) else "  PDF 없음")
    got = {key(a) for a in S.get("account", [])}
    miss = [a for k, a in want.items() if k not in got]
    print(f"\n[2] 목록에 있으나 PDF가 없는 곳 {len(miss)}곳: " + ", ".join(miss))


if __name__ == "__main__":
    main()
